package com.example.metacogroup;



public class NursePanelSpinnerClass {
    public String  name,family,emtiaz,vaziat,tedadbimaran,code_personally;
    int profile_pic;

    public String getEmtiaz() {
        return emtiaz;
    }

    public void setEmtiaz(String emtiaz) {
        this.emtiaz = emtiaz;
    }

    public String getTedadbimaran() {
        return tedadbimaran;
    }

    public void setTedadbimaran(String tedadbimaran) {
        this.tedadbimaran = tedadbimaran;
    }

    public String getCode_personally() {
        return code_personally;
    }

    public void setCode_personally(String code_personally) {
        this.code_personally = code_personally;
    }

    public int getProfile_pic() {
        return profile_pic;
    }

    public void setProfile_pic(int profile_pic) {
        this.profile_pic = profile_pic;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getFamily() {
        return family;
    }

    public void setFamily(String family) {
        this.family = family;
    }


    public String getVaziat() {
        return vaziat;
    }

    public void setVaziat(String vaziat) {
        this.vaziat = vaziat;
    }


}

