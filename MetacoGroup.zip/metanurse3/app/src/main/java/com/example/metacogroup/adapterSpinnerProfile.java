package com.example.metacogroup;

public class adapterSpinnerProfile {
}
